# Modèle LLM 8B — Langage & Codage

Implémentation complète en **PyTorch** d'un modèle de langage de **8.2 milliards de paramètres** optimisé pour le langage naturel et le codage.

## Architecture 8B (Style Llama 3 / Mistral)

- **Paramètres** : ~8.2 Billion
- **Hidden size** : 4096
- **Num hidden layers** : 32
- **Num attention heads** : 32
- **Grouped Query Attention (GQA)** : 8 KV-heads (réduction mémoire KV-cache 4×)
- **Intermediate size** : 14 336 (SwiGLU)
- **RMSNorm** : Pre-LN avec eps=1e-5
- **RoPE (Rotary Position Embeddings)** : theta=10000.0, context 32 768 tokens
- **Tête LM** : 32 768 vocab size (Weight Tying avec token embeddings)

## Structure des fichiers 8B

```
projet-llm/IA/
├── config_8b/
│   ├── config_8b.yaml         # Configuration d'architecture et hyperparamètres
│   └── ds_config_zero3.json   # Config DeepSpeed ZeRO-3 (entraînement distribué)
├── src/
│   └── model_8b/
│       └── model_8b.py        # Implémentation PyTorch du modèle 8B
└── scripts_8b/
    ├── train_8b.py            # Entraînement distribué avec DeepSpeed ZeRO-3
    └── inference_8b.py        # Génération autorégressive (inférence)
```

## Déploiement et Entraînement

### Prérequis
- Python 3.10+
- PyTorch 2.1+
- DeepSpeed (`pip install deepspeed`)
- Cluster GPU recommandé : 8× A100/H100 (80 Go) ou multi-nodes avec interconnect rapide

### Lancement de l'entraînement 8B (DeepSpeed ZeRO-3)

```bash
cd F:/Logiciels/Open_code/projet-llm

# Lancement distribué sur GPU locaux (ex: 8 GPU)
deepspeed --num_gpus=8 IA/scripts_8b/train_8b.py --deepspeed IA/config_8b/ds_config_zero3.json
```

### Inférence / Génération avec le modèle 8B

```bash
python IA/scripts_8b/inference_8b.py --prompt "def quicksort(arr):" --max-tokens 150 --temperature 0.7
```

## Stratégie pour dépasser les modèles 8B existants (2-3× plus intelligent)

1. **Données (100B tokens ultra-curés)** :
   - 40% Données scientifiques, manuels, API, Wikipédia
   - 35% Données de code de haute qualité (GitHub > 500 stars, tests unitaires)
   - 25% Données de Raisonnement (Chain-of-Thought, synthétiques GPT-4o, preuves mathématiques)
2. **Post-entraînement (SFT + DPO + RLVR)** :
   - Fine-tuning d'instruction avec DPO (Direct Preference Optimization)
   - **RLVR** (RL from Verifiable Rewards) avec exécution réelle de code et solveur logique
3. **Optimisations Inférence** :
   - Conversion vers `vLLM` ou `llama.cpp` pour inférence à très haute vitesse.
