# Documentation du LLM Langage & Codage

## Architecture

### Transformer (Décodeur)
- **Embeddings de tokens** : denses, de taille `hidden_size` (défaut 1024)
- **Embeddings de position** : appris, longueur max 4096
- **Blocs Transformer** : 24 (pré-normalisation Pre-LN)
  - Multi-Head Attention (16 têtes, masque causal pour l'autorégression)
  - Feed-Forward Network (intermédiaire 4096, activation GELU)
  - LayerNorm + Dropout + skip connections
- **Tête LM** : projection linéaire vers le vocabulaire (32 000 tokens), liée aux embeddings (weight tying)

### Attention et génération

Les deux décodeurs utilisent l’attention causale SDPA de PyTorch. Le moteur de calcul dépend du matériel et du type numérique. La variante standard utilise des positions apprises. La variante 8B utilise RoPE et conserve les clés et valeurs des 8 têtes KV de chaque couche pendant la génération. Après le traitement du prompt, elle projette uniquement le nouveau token. À la limite du contexte, le script recalcule la fenêtre glissante.

### Objectif d'entraînement
Prédiction du token suivant (next-token prediction) :
```
input_ids = [t0, t1, t2, ...]
labels    = [t0, t1, t2, ...]
loss      = CrossEntropy(logits[:, :-1], labels[:, 1:], ignore_index=-100)
```

## Tokenisation

Tokeniseur **BPE (Byte Pair Encoding)** code-aware :
- Le BPE sur octets préserve les espaces, les retours à la ligne et les caractères Unicode.
- Paires de symboles les plus fréquentes fusionnées itérativement
- Tokens spéciaux : `<pad>`, `<unk>`, `<s>`, `</s>`, `<code>`, `</code>`
- Sauvegarde/chargement en JSON

## Pipeline

1. **`preprocess.py`** : nettoie les fichiers bruts → `data/processed`
2. **`train.py`** :
   - Entraîne le tokeniseur BPE sur le corpus
   - Construit le dataset (blocs de 2048 tokens avec un token en commun et une cible ignorée pour chaque position de remplissage)
   - Entraîne le LLM (AdamW, warmup, gradient accumulation, fp16)
   - Sauvegarde des checkpoints dans `checkpoints/`
3. **`evaluate.py`** : perplexité sur un split 5 %
4. **`inference.py`** : génération de texte à partir du modèle final

## Configuration

Tous les hyperparamètres sont dans `IA/config/config.yaml`.

## Exemple d'utilisation

```bash
# 1. Prétraitement
python IA/scripts/preprocess.py

# 2. Entraînement
python IA/scripts/train.py

# 3. Évaluation
python IA/scripts/evaluate.py

# 4. Génération
python IA/scripts/inference.py --prompt "Écris une fonction en Python qui..."
```

## Notes

- L'architecture est volontairement compacte (~50 M paramètres) pour pouvoir être entraînée sur un GPU unique
- Pour un modèle plus grand, augmenter `hidden_size`, `num_hidden_layers` et `intermediate_size`
- Les checkpoints sont sauvegardés toutes les 1 000 étapes