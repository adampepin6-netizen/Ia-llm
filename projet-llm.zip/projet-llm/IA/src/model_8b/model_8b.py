"""
Architecture LLM 8B moderne :
- RMSNorm
- RoPE (Rotary Position Embeddings)
- SwiGLU FFN
- Grouped Query Attention (GQA)
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint


class RMSNorm(nn.Module):
    """Root Mean Square Layer Normalization (Llama style)."""

    def __init__(self, dim: int, eps: float = 1e-5):
        super().__init__()
        self.eps = eps
        self.weight = nn.Parameter(torch.ones(dim))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        variance = x.float().pow(2).mean(-1, keepdim=True)
        return (x.float() * torch.rsqrt(variance + self.eps)).to(x.dtype) * self.weight


class RotaryEmbedding(nn.Module):
    """Rotary Position Embeddings (RoPE)."""

    def __init__(self, dim: int, max_position: int = 32768, base: float = 10000.0):
        super().__init__()
        self.dim = dim
        self.max_position = max_position
        inv_freq = 1.0 / (base ** (torch.arange(0, dim, 2).float() / dim))
        self.register_buffer("inv_freq", inv_freq, persistent=False)

        # Precompute cos et sin
        t = torch.arange(max_position, dtype=torch.float)
        freqs = torch.outer(t, inv_freq)
        emb = torch.cat((freqs, freqs), dim=-1)
        self.register_buffer("cos_cached", emb.cos(), persistent=False)
        self.register_buffer("sin_cached", emb.sin(), persistent=False)

    def forward(self, x: torch.Tensor, seq_len: int, offset: int = 0):
        return (
            self.cos_cached[offset:offset + seq_len, :].to(x.device),
            self.sin_cached[offset:offset + seq_len, :].to(x.device),
        )


def rotate_half(x: torch.Tensor) -> torch.Tensor:
    x1 = x[..., : x.shape[-1] // 2]
    x2 = x[..., x.shape[-1] // 2 :]
    return torch.cat((-x2, x1), dim=-1)


def apply_rotary_pos_emb(q: torch.Tensor, k: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor):
    # q, k: (batch, num_heads, seq_len, head_dim)
    # cos, sin: (seq_len, head_dim) -> reshape pour broadcasting
    cos = cos.unsqueeze(0).unsqueeze(1)  # (1, 1, seq_len, head_dim)
    sin = sin.unsqueeze(0).unsqueeze(1)
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


class SwiGLUFFN(nn.Module):
    """Feed-Forward Network avec activation SwiGLU (Swish-Gated Linear Unit)."""

    def __init__(self, hidden_size: int, intermediate_size: int):
        super().__init__()
        self.w1 = nn.Linear(hidden_size, intermediate_size, bias=False)  # gate
        self.w2 = nn.Linear(intermediate_size, hidden_size, bias=False)  # down
        self.w3 = nn.Linear(hidden_size, intermediate_size, bias=False)  # up

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # SwiGLU: w2(F.silu(w1(x)) * w3(x))
        return self.w2(F.silu(self.w1(x)) * self.w3(x))


class GroupedQueryAttention(nn.Module):
    """Grouped Query Attention (GQA) pour réduire la mémoire KV-cache."""

    def __init__(self, hidden_size: int, num_heads: int, num_kv_heads: int):
        super().__init__()
        if num_heads <= 0 or num_kv_heads <= 0 or num_heads % num_kv_heads:
            raise ValueError("Le nombre de têtes Q doit être un multiple du nombre de têtes KV")
        if hidden_size % num_heads or (hidden_size // num_heads) % 2:
            raise ValueError("RoPE nécessite une dimension paire par tête")
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads
        self.head_dim = hidden_size // num_heads
        self.num_queries_per_kv = num_heads // num_kv_heads

        self.q_proj = nn.Linear(hidden_size, num_heads * self.head_dim, bias=False)
        self.k_proj = nn.Linear(hidden_size, num_kv_heads * self.head_dim, bias=False)
        self.v_proj = nn.Linear(hidden_size, num_kv_heads * self.head_dim, bias=False)
        self.o_proj = nn.Linear(num_heads * self.head_dim, hidden_size, bias=False)

    def forward(self, x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor,
                mask: torch.Tensor = None, past_kv=None, use_cache=False):
        batch_size, seq_len, _ = x.shape

        q = self.q_proj(x).view(batch_size, seq_len, self.num_heads, self.head_dim).transpose(1, 2)
        k = self.k_proj(x).view(batch_size, seq_len, self.num_kv_heads, self.head_dim).transpose(1, 2)
        v = self.v_proj(x).view(batch_size, seq_len, self.num_kv_heads, self.head_dim).transpose(1, 2)

        # RoPE
        q, k = apply_rotary_pos_emb(q, k, cos.to(q.dtype), sin.to(q.dtype))

        if past_kv is not None:
            k = torch.cat((past_kv[0], k), dim=2)
            v = torch.cat((past_kv[1], v), dim=2)
        present = (k, v) if use_cache else None

        # Repetition des clés/valeurs pour matcher les heads de query (GQA)
        if self.num_queries_per_kv > 1:
            k = k.repeat_interleave(self.num_queries_per_kv, dim=1)
            v = v.repeat_interleave(self.num_queries_per_kv, dim=1)

        output = F.scaled_dot_product_attention(q, k, v, attn_mask=mask, is_causal=mask is None and seq_len > 1)

        output = output.transpose(1, 2).contiguous().view(batch_size, seq_len, -1)
        output = self.o_proj(output)
        return (output, present) if use_cache else output


class TransformerBlock8B(nn.Module):
    """Bloc Transformer 8B (Pre-RMSNorm, GQA, SwiGLU)."""

    def __init__(self, config: dict):
        super().__init__()
        hidden_size = config["hidden_size"]
        num_heads = config["num_attention_heads"]
        num_kv_heads = config["num_key_value_heads"]
        intermediate_size = config["intermediate_size"]
        eps = config.get("rms_norm_eps", 1e-5)

        self.input_layernorm = RMSNorm(hidden_size, eps=eps)
        self.self_attn = GroupedQueryAttention(hidden_size, num_heads, num_kv_heads)
        self.post_attention_layernorm = RMSNorm(hidden_size, eps=eps)
        self.mlp = SwiGLUFFN(hidden_size, intermediate_size)

    def forward(self, x: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor,
                mask: torch.Tensor = None, past_kv=None, use_cache=False):
        # Residual + Attention
        r = x
        x = self.input_layernorm(x)
        x = self.self_attn(x, cos, sin, mask, past_kv, use_cache)
        if use_cache:
            x, present = x
        x = r + x

        # Residual + MLP
        r = x
        x = self.post_attention_layernorm(x)
        x = self.mlp(x)
        x = r + x

        return (x, present) if use_cache else x


class LLM8BModel(nn.Module):
    """
    Modèle complet LLM 8B (~8.2 milliards de paramètres).
    """

    def __init__(self, config: dict):
        super().__init__()
        self.config = config
        vocab_size = config["vocab_size"]
        hidden_size = config["hidden_size"]
        num_layers = config["num_hidden_layers"]
        eps = config.get("rms_norm_eps", 1e-5)

        self.embed_tokens = nn.Embedding(vocab_size, hidden_size)
        self.rotary_emb = RotaryEmbedding(
            dim=hidden_size // config["num_attention_heads"],
            max_position=config.get("max_position_embeddings", 32768),
            base=config.get("rope_theta", 10000.0)
        )

        self.layers = nn.ModuleList([
            TransformerBlock8B(config) for _ in range(num_layers)
        ])
        self.norm = RMSNorm(hidden_size, eps=eps)
        self.lm_head = nn.Linear(hidden_size, vocab_size, bias=False)

        # Weight Tying (optionnel, mais standard)
        self.lm_head.weight = self.embed_tokens.weight

        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                torch.nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            torch.nn.init.normal_(module.weight, mean=0.0, std=0.02)

    @staticmethod
    def create_causal_mask(seq_len: int, device: torch.device) -> torch.Tensor:
        mask = torch.full((seq_len, seq_len), float("-inf"), device=device)
        mask = torch.triu(mask, diagonal=1)
        return mask.unsqueeze(0).unsqueeze(0)

    def forward(self, input_ids: torch.Tensor, labels: torch.Tensor = None, *,
                past_key_values=None, use_cache=False, last_token_only=False) -> dict:
        batch_size, seq_len = input_ids.shape
        x = self.embed_tokens(input_ids)

        offset = 0 if past_key_values is None else past_key_values[0][0].size(2)
        if offset + seq_len > self.rotary_emb.max_position:
            raise ValueError("La séquence dépasse la fenêtre de contexte RoPE")
        cos, sin = self.rotary_emb(x, seq_len, offset)
        mask = None
        if offset and seq_len > 1:
            mask = torch.ones(seq_len, offset + seq_len, device=x.device, dtype=torch.bool).tril(offset)
        present = []

        for index, layer in enumerate(self.layers):
            past = None if past_key_values is None else past_key_values[index]
            if self.training and self.config.get("gradient_checkpointing", False) and not use_cache:
                x = checkpoint(layer, x, cos, sin, mask, past, use_reentrant=False)
            else:
                x = layer(x, cos, sin, mask, past, use_cache)
            if use_cache:
                x, kv = x
                present.append(kv)
        if last_token_only:
            if labels is not None:
                raise ValueError("Les labels nécessitent tous les logits")
            x = x[:, -1:]

        x = self.norm(x)
        logits = self.lm_head(x)

        output = {"logits": logits}

        if use_cache:
            output["past_key_values"] = present

        if labels is not None:
            shift_logits = logits[:, :-1, :].contiguous()
            shift_labels = labels[:, 1:].contiguous()
            loss_fn = nn.CrossEntropyLoss(ignore_index=-100)
            loss = loss_fn(shift_logits.view(-1, shift_logits.size(-1)),
                           shift_labels.view(-1))
            output["loss"] = loss

        return output
