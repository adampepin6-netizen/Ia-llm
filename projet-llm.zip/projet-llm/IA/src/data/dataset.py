"""
Chargement et prétraitement des données pour le LLM de langage et codage.
Lit les fichiers texte (langage + code) et construit un dataset PyTorch.
"""
import os
import glob
from typing import List, Optional

import torch
from torch.utils.data import Dataset, DataLoader

from ..tokenizer.bpe_tokenizer import BPETokenizer


class LanguageCodeDataset(Dataset):
    """
    Dataset de texte mélangé langage / code.
    Chaque élément = un bloc de tokens (seq) de taille `max_length`.
    labels alignés, décalage effectué par le modèle (next-token prediction).
    """

    def __init__(self, file_paths: List[str], tokenizer: BPETokenizer,
                 max_length: int = 2048):
        self.tokenizer = tokenizer
        self.max_length = max_length

        if max_length < 2:
            raise ValueError("max_length doit être au moins égal à 2")
        self.pad_id = tokenizer.vocab["<pad>"]
        self.blocks = []
        def token_chunks():
            for path in file_paths:
                with open(path, encoding="utf-8", errors="replace") as source:
                    for line in source:
                        yield tokenizer.encode(line)
                yield [tokenizer.vocab["</s>"]]

        pending = []
        for chunk in token_chunks():
            pending.extend(chunk)
            start = 0
            while len(pending) - start >= max_length:
                self.blocks.append(pending[start:start + max_length])
                start += max_length - 1
            pending = pending[start:]
        if len(pending) >= 2:
            self.blocks.append(pending)


    def __len__(self) -> int:
        return len(self.blocks)

    def __getitem__(self, idx: int):
        block = self.blocks[idx]
        padding = self.max_length - len(block)
        input_ids = torch.tensor(block + [self.pad_id] * padding, dtype=torch.long)
        labels = input_ids.clone()
        labels[len(block):] = -100
        return input_ids, labels


def collate_blocks(batch):
    """Écarte le remplissage commun en fin de lot avant le calcul des logits."""
    inputs, labels = zip(*batch)
    labels = torch.stack(labels)
    length = int((labels != -100).sum(dim=1).max())
    return torch.stack(inputs)[:, :length], labels[:, :length]


def build_dataloader(dataset: Dataset, batch_size: int,
                     shuffle: bool = True,
                     num_workers: int = 0,
                     pin_memory: bool = True) -> DataLoader:
    return DataLoader(dataset,
                      batch_size=batch_size,
                      shuffle=shuffle,
                      num_workers=num_workers,
                      pin_memory=pin_memory,
                      collate_fn=collate_blocks if isinstance(dataset, LanguageCodeDataset) else None,
                      drop_last=False)


def load_corpus(raw_dir: str, extensions: Optional[List[str]] = None) -> List[str]:
    """Charge tous les fichiers texte d'un dossier (langage + code)."""
    extensions = extensions or [".txt", ".py", ".js", ".ts", ".java", ".c",
                                 ".cpp", ".cs", ".go", ".rs", ".md", ".json"]
    file_paths = []
    for ext in extensions:
        file_paths.extend(glob.glob(os.path.join(raw_dir, "**", "*" + ext),
                                    recursive=True))
    # dédupliquer et trier pour la reproductibilité
    file_paths = sorted(set(file_paths))
    print(f"Corpus : {len(file_paths)} fichiers trouvés dans {raw_dir}")
    return file_paths
