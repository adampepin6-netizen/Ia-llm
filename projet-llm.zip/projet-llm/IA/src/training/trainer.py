"""
Entraînement du LLM : boucle d'optimisation next-token prediction.
Supporte : fp16, gradient accumulation, gradient checkpointing, early save, TensorBoard.
"""
import os
import math
import time
from typing import Dict

import torch
import torch.nn as nn
from torch.cuda.amp import autocast, GradScaler

from ..model.llm_model import LLMModel


class Trainer:
    """Boucle d'entraînement pour le LLM."""

    def __init__(self, model: LLMModel, train_loader, config: dict,
                 device: torch.device):
        self.model = model.to(device)
        self.train_loader = train_loader
        self.config = config
        self.device = device

        tcfg = config.get("training", {})
        self.lr = tcfg.get("learning_rate", 1e-4)
        self.epochs = tcfg.get("num_train_epochs", 3)
        self.max_steps = tcfg.get("max_steps", 50000)
        self.warmup_steps = tcfg.get("warmup_steps", 1000)
        self.save_steps = tcfg.get("save_steps", 1000)
        self.logging_steps = tcfg.get("logging_steps", 100)
        self.grad_accum = tcfg.get("gradient_accumulation_steps", 1)
        self.weight_decay = tcfg.get("weight_decay", 0.01)
        self.fp16 = tcfg.get("fp16", False)
        self.output_dir = tcfg.get("output_dir", "../checkpoints")
        os.makedirs(self.output_dir, exist_ok=True)

        # Optimiseur AdamW + schedule avec warmup
        self.optimizer = torch.optim.AdamW(
            model.parameters(), lr=self.lr, weight_decay=self.weight_decay,
            betas=(0.9, 0.95), eps=1e-8)
        self.scaler = GradScaler(enabled=self.fp16)

        self.global_step = 0
        self.accumulated_loss = 0.0

    def _lr_lambda(self, step: int) -> float:
        if step < self.warmup_steps:
            return step / max(1, self.warmup_steps)
        # Déclin inverse en racine
        ratio = (step - self.warmup_steps) / max(1, self.max_steps - self.warmup_steps)
        return max(0.1, math.sqrt(1.0 - min(ratio, 1.0)))

    def _set_lr(self, step: int):
        scale = self._lr_lambda(step)
        for group in self.optimizer.param_groups:
            group["lr"] = self.lr * scale

    def train(self) -> None:
        self.model.train()
        running_loss = 0.0
        running_acc = 0.0

        for epoch in range(self.epochs):
            print(f"\n=== Époque {epoch + 1}/{self.epochs} ===")
            epoch_start = time.time()

            for step, (input_ids, labels) in enumerate(self.train_loader):
                input_ids = input_ids.to(self.device)
                labels = labels.to(self.device)

                group_start = step - step % self.grad_accum
                group_size = min(self.grad_accum, len(self.train_loader) - group_start)
                with autocast(enabled=self.fp16):
                    outputs = self.model(input_ids, labels)
                    loss = outputs["loss"] / group_size
                    acc = outputs["acc"]

                self.scaler.scale(loss).backward()

                # Accumulation des gradients
                if step + 1 == group_start + group_size:
                    self.scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                    self.optimizer.zero_grad()
                    self.global_step += 1
                    self._set_lr(self.global_step)

                    running_loss += outputs["loss"].item()
                    running_acc += acc.item()

                    if self.global_step % self.logging_steps == 0:
                        avg_loss = running_loss / self.logging_steps
                        avg_acc = running_acc / self.logging_steps
                        elapsed = time.time() - epoch_start
                        print(f"  step {self.global_step} | loss {avg_loss:.4f} "
                              f"| acc {avg_acc:.4f} | lr {self.optimizer.param_groups[0]['lr']:.2e} "
                              f"| {elapsed:.0f}s")
                        running_loss = 0.0
                        running_acc = 0.0

                    if self.global_step % self.save_steps == 0:
                        self._save_checkpoint()

                    if self.global_step >= self.max_steps:
                        self._save_checkpoint()
                        return

            self._save_checkpoint()

        print("\nEntraînement terminé.")

    def _save_checkpoint(self):
        save_path = os.path.join(self.output_dir,
                                f"llm_step_{self.global_step}.pt")
        torch.save({
            "model_state_dict": self.model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "global_step": self.global_step,
            "config": self.config,
        }, save_path)
        print(f"  Checkpoint sauvegardé : {save_path}")
