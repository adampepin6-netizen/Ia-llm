"""
Utilitaires : logging, gestion de la configuration, etc.
"""
import os
import json
import yaml
import torch


def load_config(path: str) -> dict:
    """Charge un fichier YAML ou JSON en dictionnaire."""
    with open(path, "r", encoding="utf-8") as f:
        if path.endswith(".json"):
            return json.load(f)
        return yaml.safe_load(f)


def save_config(config: dict, path: str):
    """Sauvegarde la configuration en YAML."""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        yaml.dump(config, f, default_flow_style=False, allow_unicode=True)


def get_device() -> torch.device:
    """Retourne le device CUDA si disponible, sinon CPU."""
    if torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")


def set_seed(seed: int = 42):
    """Fixe les graines aléatoires pour la reproductibilité."""
    import random
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)