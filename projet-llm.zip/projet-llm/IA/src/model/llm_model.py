"""
LLMModel : modèle de langage pour le langage naturel ET le codage.
Ajoute la tête de classification (prédiction du token suivant) au Transformer.
"""
import torch
import torch.nn as nn

from .transformer_model import TransformerModel


class LLMModel(nn.Module):
    """
    LLM pour le langage et le codage.
    - Prédiction du token suivant (autoregressive next-token prediction)
    - Tokens spéciaux <code> / </code> pour le domaine codage
    """

    def __init__(self, config: dict):
        super().__init__()
        self.config = config
        self.backbone = TransformerModel(config)
        self.lm_head = nn.Linear(config.get("hidden_size", 1024),
                                 config.get("vocab_size", 32000), bias=False)

        # Liage des poids embeddings / tête de sortie (weight tying)
        self.lm_head.weight = self.backbone.token_embedding.weight

    def forward(self, input_ids: torch.Tensor, labels: torch.Tensor = None,
                attention_mask: torch.Tensor = None) -> dict:
        hidden_states = self.backbone(input_ids, attention_mask)
        logits = self.lm_head(hidden_states)

        output = {"logits": logits}

        if labels is not None:
            loss_fn = nn.CrossEntropyLoss(ignore_index=-100)
            # Décalage : on prédit le token i+1 à partir de la position i
            shift_logits = logits[:, :-1, :].contiguous()
            shift_labels = labels[:, 1:].contiguous()
            output["loss"] = loss_fn(shift_logits.view(-1, shift_logits.size(-1)),
                                     shift_labels.view(-1))
            valid = shift_labels != -100
            correct = shift_logits.argmax(dim=-1) == shift_labels
            output["acc"] = (correct & valid).sum() / valid.sum().clamp_min(1)

        return output

    @torch.no_grad()
    def generate(self, input_ids: torch.Tensor, max_new_tokens: int = 100,
                 temperature: float = 0.7, top_k: int = 50, vocab_size: int = None,
                 eos_token_id: int = None) -> torch.Tensor:
        """Génération de texte (décodage par échantillonnage avec top-k)."""
        if eos_token_id is None:
            eos_token_id = self.config.get("eos_token_id", 3)
        generated = input_ids
        for _ in range(max_new_tokens):
            outputs = self(generated[:, -self.backbone.position_embedding.num_embeddings:])
            logits = outputs["logits"][:, -1, :vocab_size] / max(temperature, 1e-5)

            # Top-k
            if top_k:
                indices_to_remove = logits < torch.topk(logits, min(top_k, logits.size(-1)))[0][..., -1, None]
                logits[indices_to_remove] = float("-inf")

            probs = torch.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            generated = torch.cat([generated, next_token], dim=-1)

            # Stop si token </s>
            if (next_token == eos_token_id).all():
                break
        return generated
