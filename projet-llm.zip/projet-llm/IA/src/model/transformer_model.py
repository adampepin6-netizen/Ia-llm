"""
Architecture Transformer pour le LLM de langage et codage.
Implémentation des blocs Transformer (Multi-Head Attention + FFN).
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint


class MultiHeadAttention(nn.Module):
    """Attention multi-têtes avec mécanisme de causalité pour le décodage."""

    def __init__(self, hidden_size: int, num_heads: int, dropout: float = 0.1):
        super().__init__()
        assert hidden_size % num_heads == 0, "hidden_size doit être divisible par num_heads"

        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads

        self.q_proj = nn.Linear(hidden_size, hidden_size)
        self.k_proj = nn.Linear(hidden_size, hidden_size)
        self.v_proj = nn.Linear(hidden_size, hidden_size)
        self.out_proj = nn.Linear(hidden_size, hidden_size)
        self.dropout = nn.Dropout(dropout)

    def _split_heads(self, x: torch.Tensor, batch_size: int) -> torch.Tensor:
        # (batch, seq, hidden) -> (batch, heads, seq, head_dim)
        return x.view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)

    def forward(self, hidden_states: torch.Tensor, attention_mask: torch.Tensor = None) -> torch.Tensor:
        batch_size, seq_len, _ = hidden_states.shape

        q = self._split_heads(self.q_proj(hidden_states), batch_size)
        k = self._split_heads(self.k_proj(hidden_states), batch_size)
        v = self._split_heads(self.v_proj(hidden_states), batch_size)

        attn_output = F.scaled_dot_product_attention(
            q, k, v, attn_mask=attention_mask, is_causal=attention_mask is None,
            dropout_p=self.dropout.p if self.training else 0.0,
        )

        # Re-fusion des têtes
        attn_output = attn_output.transpose(1, 2).contiguous().view(batch_size, seq_len, -1)

        return self.out_proj(attn_output)


class FeedForward(nn.Module):
    """Feed-Forward Network (position-wise) avec GELU."""

    def __init__(self, hidden_size: int, intermediate_size: int, dropout: float = 0.1):
        super().__init__()
        self.dense = nn.Linear(hidden_size, intermediate_size)
        self.intermediate_act = nn.GELU()
        self.dropout = nn.Dropout(dropout)
        self.output = nn.Linear(intermediate_size, hidden_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.output(self.dropout(self.intermediate_act(self.dense(x))))


class TransformerBlock(nn.Module):
    """Bloc Transformer pré-normalisation (Pre-LN): attention + FFN avec skip connections."""

    def __init__(self, hidden_size: int, num_heads: int, intermediate_size: int,
                 dropout: float = 0.1, layer_norm_eps: float = 1e-12):
        super().__init__()
        self.ln1 = nn.LayerNorm(hidden_size, eps=layer_norm_eps)
        self.attention = MultiHeadAttention(hidden_size, num_heads, dropout)
        self.ln2 = nn.LayerNorm(hidden_size, eps=layer_norm_eps)
        self.ffn = FeedForward(hidden_size, intermediate_size, dropout)

    def forward(self, hidden_states: torch.Tensor, attention_mask: torch.Tensor = None) -> torch.Tensor:
        # Skip connection autour de l'attention
        residual = hidden_states
        hidden_states = self.ln1(hidden_states)
        hidden_states = self.attention(hidden_states, attention_mask)
        hidden_states = residual + hidden_states

        # Skip connection autour du FFN
        residual = hidden_states
        hidden_states = self.ln2(hidden_states)
        hidden_states = self.ffn(hidden_states)
        hidden_states = residual + hidden_states

        return hidden_states


class TransformerModel(nn.Module):
    """
    Modèle Transformer complet (décodeur) pour le LLM.
    Embeddings de position appris + stack de blocs Transformer.
    """

    def __init__(self, config: dict):
        super().__init__()
        vocab_size = config.get("vocab_size", 32000)
        hidden_size = config.get("hidden_size", 1024)
        num_layers = config.get("num_hidden_layers", 24)
        num_heads = config.get("num_attention_heads", 16)
        intermediate_size = config.get("intermediate_size", 4096)
        max_positions = config.get("max_position_embeddings", 4096)
        dropout = config.get("hidden_dropout_prob", 0.1)
        eps = config.get("layer_norm_eps", 1e-12)

        self.token_embedding = nn.Embedding(vocab_size, hidden_size)
        self.position_embedding = nn.Embedding(max_positions, hidden_size)
        self.dropout = nn.Dropout(dropout)

        self.blocks = nn.ModuleList([
            TransformerBlock(hidden_size, num_heads, intermediate_size, dropout, eps)
            for _ in range(num_layers)
        ])
        self.final_norm = nn.LayerNorm(hidden_size, eps=eps)

        # Initialisation des poids
        self.apply(self._init_weights)
        self.gradient_checkpointing = config.get("gradient_checkpointing", False)
        self.hidden_size = hidden_size

    def _init_weights(self, module: nn.Module):
        if isinstance(module, nn.Linear):
            module.weight.data.normal_(mean=0.0, std=0.02)
            if module.bias is not None:
                module.bias.data.zero_()
        elif isinstance(module, nn.Embedding):
            module.weight.data.normal_(mean=0.0, std=0.02)

    @staticmethod
    def create_causal_mask(seq_len: int, device: torch.device) -> torch.Tensor:
        """Masque causal (inférieur stricte): les positions ne voient pas le futur."""
        mask = torch.tril(torch.ones(seq_len, seq_len, dtype=torch.float, device=device))
        mask = mask.masked_fill(mask == 0, float("-inf"))
        return mask.unsqueeze(0).unsqueeze(0)  # (1, 1, seq, seq)

    def forward(self, input_ids: torch.Tensor, attention_mask: torch.Tensor = None) -> torch.Tensor:
        batch_size, seq_len = input_ids.shape
        positions = torch.arange(seq_len, device=input_ids.device).unsqueeze(0)

        hidden_states = self.token_embedding(input_ids) + self.position_embedding(positions)
        hidden_states = self.dropout(hidden_states)

        # Masque causal pour l'autorégression
        causal_mask = None
        if attention_mask is not None:
            if attention_mask.shape != input_ids.shape:
                raise ValueError("attention_mask doit avoir la forme (batch, séquence)")
            causal = torch.ones(seq_len, seq_len, device=input_ids.device, dtype=torch.bool).tril()
            causal_mask = causal & attention_mask[:, None, None, :].bool()

        for block in self.blocks:
            if self.gradient_checkpointing and self.training:
                hidden_states = checkpoint(block, hidden_states, causal_mask, use_reentrant=False)
            else:
                hidden_states = block(hidden_states, causal_mask)

        return self.final_norm(hidden_states)
