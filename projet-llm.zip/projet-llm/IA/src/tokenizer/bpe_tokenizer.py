"""BPE sur octets pour le texte et le code, avec lecture des anciens fichiers JSON."""
import re
import json
import os
from typing import Iterable, List, Dict, Tuple

# Expression historique requise pour reproduire les IDs des anciens tokeniseurs.
CODE_AWARE_PRETOKEN = re.compile(
    r"""'?'
    | [^\s'`_{}()\[\]]+         # identifiants / mots
    | \s+                        # espaces
    | [^'`a-zA-Z0-9]            # symboles ponctuation / opérateurs
    """
)


class BPETokenizer:
    """Tokeniseur BPE entraînable, persistant en JSON."""

    def __init__(self, vocab_size: int = 32000,
                 special_tokens: List[str] = None):
        self.backend = None
        self.vocab_size = vocab_size
        self.special_tokens = special_tokens or ["<pad>", "<unk>", "<s>", "</s>"]

        # vocab : token -> id
        self.vocab: Dict[str, int] = {tok: i for i, tok in enumerate(self.special_tokens)}
        # id -> token (liste pour accès O(1))
        self.id_to_token: List[str] = list(self.special_tokens)
        # paires BPE : (left, right) -> fréquence
        self.merges: Dict[Tuple[str, str], float] = {}
        self.unk_id = self.vocab.get("<unk>", 1)

    # -------------------------------------------------------------
    # Prétokenisation
    # -------------------------------------------------------------
    def pretokenize(self, text: str) -> List[str]:
        """Découpe le texte en sous-mots (code-aware)."""
        if self.backend is not None:
            return [part for part, _ in self.backend.pre_tokenizer.pre_tokenize_str(text)]
        return CODE_AWARE_PRETOKEN.findall(text)

    # -------------------------------------------------------------
    # Entraînement du BPE
    # -------------------------------------------------------------
    def train(self, corpus: Iterable[str], min_frequency: int = 2, verbose: bool = True):
        """
        Entraîne le BPE sur le corpus.
        corpus : liste de chaînes de texte (langage + code).
        """
        from tokenizers import Tokenizer, decoders, models, pre_tokenizers, trainers

        alphabet = pre_tokenizers.ByteLevel.alphabet()
        if self.vocab_size < len(alphabet) + len(self.special_tokens):
            raise ValueError("Vocabulaire insuffisant pour couvrir tous les octets")
        backend = Tokenizer(models.BPE(unk_token="<unk>"))
        backend.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
        backend.decoder = decoders.ByteLevel()
        trainer = trainers.BpeTrainer(
            vocab_size=self.vocab_size, min_frequency=min_frequency,
            special_tokens=self.special_tokens, initial_alphabet=alphabet,
            show_progress=verbose,
        )
        backend.train_from_iterator(corpus, trainer=trainer)
        self._set_backend(backend)

    def _set_backend(self, backend):
        self.backend = backend
        self.vocab = backend.get_vocab()
        self.id_to_token = sorted(self.vocab, key=self.vocab.get)
        self.unk_id = self.vocab["<unk>"]

    # -------------------------------------------------------------
    # Encodage / Décodage
    # -------------------------------------------------------------
    def encode(self, text: str) -> List[int]:
        """Encode du texte en IDs de tokens."""
        if self.backend is not None:
            return self.backend.encode(text).ids
        tokens = self.pretokenize(text)
        ids = []
        for tok in tokens:
            ids.append(self.vocab.get(tok, self.unk_id))
        return ids

    def decode(self, ids: List[int]) -> str:
        """Décode une liste d'IDs en texte."""
        if self.backend is not None:
            return self.backend.decode(ids, skip_special_tokens=False)
        tokens = []
        for i in ids:
            if 0 <= i < len(self.id_to_token):
                tokens.append(self.id_to_token[i])
            else:
                tokens.append(self.id_to_token[self.unk_id])
        return "".join(tokens)

    # -------------------------------------------------------------
    # Sauvegarde / Chargement
    # -------------------------------------------------------------
    def save(self, path: str):
        data = {"special_tokens": self.special_tokens, "vocab_size": self.vocab_size}
        if self.backend is None:
            data.update(vocab=self.vocab, id_to_token=self.id_to_token,
                        merges={" ".join(pair): freq for pair, freq in self.merges.items()})
        else:
            data["backend"] = json.loads(self.backend.to_str())
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    @classmethod
    def load(cls, path: str) -> "BPETokenizer":
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        tok = cls(vocab_size=data["vocab_size"], special_tokens=data["special_tokens"])
        if "backend" in data:
            from tokenizers import Tokenizer
            tok._set_backend(Tokenizer.from_str(json.dumps(data["backend"])))
            return tok
        tok.vocab = data["vocab"]
        tok.id_to_token = data["id_to_token"]
        tok.merges = {tuple(k.split(" ", 1)): v for k, v in data["merges"].items()}
        tok.unk_id = tok.vocab.get("<unk>", 1)
        return tok

    def __len__(self):
        return len(self.vocab)
