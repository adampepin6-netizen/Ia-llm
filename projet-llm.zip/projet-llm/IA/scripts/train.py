"""
Script d'entraînement principal du LLM.
Usage : python IA/scripts/train.py
"""
import os
import sys
import torch
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.model.llm_model import LLMModel
from src.data.dataset import LanguageCodeDataset, build_dataloader, load_corpus
from src.tokenizer.bpe_tokenizer import BPETokenizer
from src.training.trainer import Trainer
from src.utils import load_config, get_device, set_seed


def main():
    set_seed(42)
    config_path = os.path.join(os.path.dirname(__file__), "..", "config", "config.yaml")
    config = load_config(config_path)

    device = get_device()
    print(f"Device : {device}")

    # 1. Chargement / création du tokeniseur
    tokenizer_path = os.path.join(os.path.dirname(__file__), "..", "data", "tokenizer.json")
    if os.path.exists(tokenizer_path):
        tokenizer = BPETokenizer.load(tokenizer_path)
        print("Tokeniseur chargé.")
    else:
        print("Entraînement du tokeniseur...")
        raw_dir = os.path.join(os.path.dirname(__file__), "..", "data", "raw")
        file_paths = load_corpus(raw_dir)
        if not file_paths:
            raise RuntimeError("Aucun fichier de données dans data/raw. Ajoutez des fichiers .txt/.py/etc.")
        tokenizer = BPETokenizer(vocab_size=config["model"]["vocab_size"],
                                 special_tokens=config["tokenizer"]["special_tokens"])
        def corpus_lines():
            for path in file_paths:
                with open(path, encoding="utf-8", errors="replace") as source:
                    yield from source
        tokenizer.train(corpus_lines())
        tokenizer.save(tokenizer_path)

    # 2. Chargement du dataset
    raw_dir = os.path.join(os.path.dirname(__file__), "..", "data", "raw")
    file_paths = load_corpus(raw_dir)
    if not file_paths:
        raise RuntimeError("Aucun fichier de données dans data/raw.")
    dataset = LanguageCodeDataset(file_paths, tokenizer,
                                  max_length=config["data"]["max_length"])
    dataloader = build_dataloader(dataset,
                                  batch_size=config["training"]["batch_size"],
                                  shuffle=True)

    # 3. Création du modèle
    model = LLMModel(dict(config["model"], gradient_checkpointing=config["training"].get(
        "gradient_checkpointing", False)))
    total_params = sum(p.numel() for p in model.parameters()) / 1e6
    print(f"Modèle : {total_params:.2f}M paramètres")

    # 4. Entraînement
    config["training"]["output_dir"] = os.path.abspath(os.path.join(
        os.path.dirname(__file__), config["training"]["output_dir"]))
    trainer = Trainer(model, dataloader, config, device)
    trainer.train()

    # 5. Sauvegarde finale
    final_path = os.path.join(os.path.dirname(__file__), "..", "checkpoints", "llm_final.pt")
    os.makedirs(os.path.dirname(final_path), exist_ok=True)
    torch.save(model.state_dict(), final_path)
    print(f"Modèle final sauvegardé : {final_path}")


if __name__ == "__main__":
    main()