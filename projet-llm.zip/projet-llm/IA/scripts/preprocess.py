"""
Script de prétraitement des données.
Charge les fichiers bruts, les nettoie et les sauvegarde dans data/processed.
Usage : python IA/scripts/preprocess.py
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.data.dataset import load_corpus


def main():
    raw_dir = os.path.join(os.path.dirname(__file__), "..", "data", "raw")
    processed_dir = os.path.join(os.path.dirname(__file__), "..", "data", "processed")
    os.makedirs(processed_dir, exist_ok=True)

    file_paths = load_corpus(raw_dir)
    print(f"Fichiers trouvés : {len(file_paths)}")

    # Nettoyage basique : supprimer les lignes trop courtes, les lignes binaires
    total_lines = 0
    for path in file_paths:
        out_name = Path(path).stem + ".txt"
        out_path = os.path.join(processed_dir, out_name)
        with open(path, "r", encoding="utf-8", errors="ignore") as fin, \
             open(out_path, "w", encoding="utf-8") as fout:
            for line in fin:
                if line and not any(b in line for b in ["\x00", "\x01", "\x02"]):
                    fout.write(line)
                    total_lines += 1

    print(f"Lignes nettoyées : {total_lines}")


if __name__ == "__main__":
    main()