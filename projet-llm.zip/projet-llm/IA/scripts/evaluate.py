"""
Script d'évaluation : calcule la perplexité sur un ensemble de validation.
Usage : python IA/scripts/evaluate.py
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import torch

from src.model.llm_model import LLMModel
from src.data.dataset import LanguageCodeDataset, build_dataloader, load_corpus
from src.tokenizer.bpe_tokenizer import BPETokenizer
from src.utils import load_config, get_device


def main():
    config_path = os.path.join(os.path.dirname(__file__), "..", "config", "config.yaml")
    config = load_config(config_path)
    device = get_device()

    tokenizer_path = os.path.join(os.path.dirname(__file__), "..", "data", "tokenizer.json")
    tokenizer = BPETokenizer.load(tokenizer_path)

    raw_dir = os.path.join(os.path.dirname(__file__), "..", "data", "raw")
    file_paths = load_corpus(raw_dir)
    if not file_paths:
        print("Aucune donnée pour l'évaluation.")
        return

    # Split 95/5
    split = int(len(file_paths) * 0.95)
    val_files = file_paths[split:]
    dataset = LanguageCodeDataset(val_files, tokenizer,
                                  max_length=config["data"]["max_length"])
    dataloader = build_dataloader(dataset, batch_size=config["training"]["batch_size"],
                                  shuffle=False)

    model = LLMModel(config["model"]).to(device)
    checkpoint_path = os.path.join(os.path.dirname(__file__), "..", "checkpoints", "llm_final.pt")
    if os.path.exists(checkpoint_path):
        model.load_state_dict(torch.load(checkpoint_path, map_location=device))
    model.eval()

    total_loss = 0.0
    total_tokens = 0
    with torch.no_grad():
        for input_ids, labels in dataloader:
            input_ids = input_ids.to(device)
            labels = labels.to(device)
            outputs = model(input_ids, labels)
            count = (labels[:, 1:] != -100).sum().item()
            total_loss += outputs["loss"].item() * count
            total_tokens += count

    avg_loss = total_loss / max(1, total_tokens)
    perplexity = torch.exp(torch.tensor(avg_loss))
    print(f"Loss : {avg_loss:.4f} | Perplexité : {perplexity:.2f}")


if __name__ == "__main__":
    main()