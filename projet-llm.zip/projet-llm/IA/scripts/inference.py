"""
Script d'inférence : génération de texte à partir du LLM entraîné.
Usage : python IA/scripts/inference.py --prompt "Bonjour"
"""
import os
import sys
import argparse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import torch

from src.model.llm_model import LLMModel
from src.tokenizer.bpe_tokenizer import BPETokenizer
from src.utils import load_config, get_device


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prompt", type=str, default="Bonjour, comment vas-tu ?")
    parser.add_argument("--max-tokens", type=int, default=100)
    parser.add_argument("--temperature", type=float, default=0.7)
    parser.add_argument("--top-k", type=int, default=50)
    args = parser.parse_args()

    config_path = os.path.join(os.path.dirname(__file__), "..", "config", "config.yaml")
    config = load_config(config_path)
    device = get_device()

    tokenizer_path = os.path.join(os.path.dirname(__file__), "..", "data", "tokenizer.json")
    tokenizer = BPETokenizer.load(tokenizer_path)

    model = LLMModel(config["model"]).to(device)
    checkpoint_path = os.path.join(os.path.dirname(__file__), "..", "checkpoints", "llm_final.pt")
    if os.path.exists(checkpoint_path):
        model.load_state_dict(torch.load(checkpoint_path, map_location=device))
        print(f"Modèle chargé depuis {checkpoint_path}")
    else:
        print("Aucun checkpoint final. Utilisation des poids initiaux.")

    model.eval()

    input_ids = torch.tensor(tokenizer.encode(args.prompt), dtype=torch.long).unsqueeze(0).to(device)
    with torch.no_grad():
        generated = model.generate(input_ids, max_new_tokens=args.max_tokens,
                                   temperature=args.temperature, top_k=args.top_k,
                                   vocab_size=len(tokenizer), eos_token_id=tokenizer.vocab["</s>"])

    output_text = tokenizer.decode(generated[0].tolist())
    print(f"\n--- Généré ---\n{output_text}")


if __name__ == "__main__":
    main()