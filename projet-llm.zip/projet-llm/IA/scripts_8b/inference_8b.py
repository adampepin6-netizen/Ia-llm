"""
Script d'inférence pour le modèle LLM 8B (supporte la génération autorégressive).
Usage : python IA/scripts_8b/inference_8b.py --prompt "def quicksort(arr):"
"""
import os
import sys
import argparse
import torch
import yaml
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.model_8b.model_8b import LLM8BModel
from src.tokenizer.bpe_tokenizer import BPETokenizer


def load_yaml(path):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


@torch.no_grad()
def generate(model, input_ids, max_new_tokens=100, temperature=0.7, top_k=50,
             vocab_size=None, eos_token_id=None):
    model.eval()
    generated = input_ids
    cache = None
    window = model.rotary_emb.max_position
    current = generated[:, -window:]
    for _ in range(max_new_tokens):
        outputs = model(current, past_key_values=cache, use_cache=True, last_token_only=True)
        cache = outputs["past_key_values"]
        logits = outputs["logits"][:, -1, :vocab_size] / max(temperature, 1e-5)

        if top_k > 0:
            v, _ = torch.topk(logits, min(top_k, logits.size(-1)))
            logits[logits < v[:, [-1]]] = float("-inf")

        probs = torch.softmax(logits, dim=-1)
        next_token = torch.multinomial(probs, num_samples=1)
        generated = torch.cat([generated, next_token], dim=-1)
        if eos_token_id is not None and (next_token == eos_token_id).all():
            break
        if cache[0][0].size(2) == window:
            current = generated[:, -window:]
            cache = None
        else:
            current = next_token
    return generated


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prompt", type=str, default="Voici un exemple de code Python :")
    parser.add_argument("--max-tokens", type=int, default=100)
    parser.add_argument("--temperature", type=float, default=0.7)
    args = parser.parse_args()

    config_path = os.path.join(os.path.dirname(__file__), "..", "config_8b", "config_8b.yaml")
    config = load_yaml(config_path)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device : {device}")

    tokenizer_path = os.path.join(os.path.dirname(__file__), "..", "data", "tokenizer.json")
    tokenizer = BPETokenizer.load(tokenizer_path)

    print("Instanciation du modèle 8B...")
    model = LLM8BModel(config["model"]).to(device)

    # Note: En production, charger le checkpoint DeepSpeed ici
    checkpoint_path = os.path.join(os.path.dirname(__file__), "..", "checkpoints_8b", "llm_8b_final.pt")
    if os.path.exists(checkpoint_path):
        model.load_state_dict(torch.load(checkpoint_path, map_location=device))
        print(f"Checkpoint 8B chargé depuis {checkpoint_path}")

    input_ids = torch.tensor(tokenizer.encode(args.prompt), dtype=torch.long).unsqueeze(0).to(device)
    print("Génération en cours...")
    output_ids = generate(model, input_ids, max_new_tokens=args.max_tokens, temperature=args.temperature,
                          vocab_size=len(tokenizer), eos_token_id=tokenizer.vocab["</s>"])
    text = tokenizer.decode(output_ids[0].tolist())

    print(f"\n--- Output Généré (LLM 8B) ---\n{text}")


if __name__ == "__main__":
    main()
