#!/usr/bin/env python3
"""
Benchmark du modèle 8B : vitesse & mémoire
- Forward avec / sans KV cache
- Avec / sans gradient checkpointing
- Génération token par token vs full forward
"""
import sys
import os
import time
import gc
import torch
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.model_8b.model_8b import LLM8BModel
from src.tokenizer.bpe_tokenizer import BPETokenizer


def get_memory_mb():
    """Mémoire CPU en MB (approx)."""
    import psutil
    process = psutil.Process(os.getpid())
    return process.memory_info().rss / 1024 / 1024


def benchmark_forward(model, input_ids, name, warmup=3, runs=10):
    """Benchmark forward pass."""
    model.eval()
    
    # Warmup
    with torch.no_grad():
        for _ in range(warmup):
            _ = model(input_ids)
    
    # Timed runs
    torch.cuda.synchronize() if torch.cuda.is_available() else None
    start = time.perf_counter()
    with torch.no_grad():
        for _ in range(runs):
            _ = model(input_ids)
    torch.cuda.synchronize() if torch.cuda.is_available() else None
    elapsed = time.perf_counter() - start
    
    mem = get_memory_mb()
    print(f"{name:40s} | {elapsed/runs*1000:7.2f} ms/forward | {runs/elapsed:6.1f} it/s | RAM: {mem:.0f} MB")
    return elapsed / runs


@torch.no_grad()
def generate_with_cache(model, input_ids, max_new_tokens, vocab_size=None):
    """Génération avec cache KV."""
    model.eval()
    generated = input_ids
    cache = None
    window = model.rotary_emb.max_position
    current = generated[:, -window:]
    for _ in range(max_new_tokens):
        outputs = model(current, past_key_values=cache, use_cache=True, last_token_only=True)
        cache = outputs["past_key_values"]
        logits = outputs["logits"][:, -1, :vocab_size] if vocab_size else outputs["logits"][:, -1]
        next_token = logits.argmax(-1, keepdim=True)
        generated = torch.cat([generated, next_token], dim=-1)
        if cache[0][0].size(2) == window:
            current = generated[:, -window:]
            cache = None
        else:
            current = next_token
    return generated


def benchmark_generation(model, input_ids, max_new_tokens, name, vocab_size, runs=5):
    """Benchmark génération autorégressive avec cache KV."""
    
    # Warmup
    with torch.no_grad():
        _ = generate_with_cache(model, input_ids, max_new_tokens, vocab_size)
    
    torch.cuda.synchronize() if torch.cuda.is_available() else None
    start = time.perf_counter()
    with torch.no_grad():
        for _ in range(runs):
            _ = generate_with_cache(model, input_ids, max_new_tokens, vocab_size)
    torch.cuda.synchronize() if torch.cuda.is_available() else None
    elapsed = time.perf_counter() - start
    
    tokens_per_sec = (max_new_tokens * runs) / elapsed
    print(f"{name:40s} | {elapsed/runs*1000:7.2f} ms  | {tokens_per_sec:6.1f} tok/s")
    return elapsed / runs


def benchmark_grad_checkpoint(model, input_ids, labels, name, runs=5):
    """Benchmark backward pass avec gradient checkpointing."""
    model.train()
    
    # Warmup
    for _ in range(2):
        out = model(input_ids, labels=labels)
        out["loss"].backward()
        model.zero_grad()
    
    torch.cuda.synchronize() if torch.cuda.is_available() else None
    start = time.perf_counter()
    for _ in range(runs):
        out = model(input_ids, labels=labels)
        out["loss"].backward()
        model.zero_grad()
    torch.cuda.synchronize() if torch.cuda.is_available() else None
    elapsed = time.perf_counter() - start
    
    mem = get_memory_mb()
    print(f"{name:40s} | {elapsed/runs*1000:7.2f} ms/step | RAM: {mem:.0f} MB")
    return elapsed / runs


def main():
    print("=" * 80)
    print("BENCHMARK LLM 8B (CPU)")
    print("=" * 80)
    
    # Config réduite pour test rapide (comme dans les tests)
    config = dict(
        hidden_size=512,
        num_attention_heads=8,
        num_key_value_heads=2,
        num_hidden_layers=8,
        intermediate_size=1536,
        vocab_size=320,
        max_position_embeddings=2048,
        rms_norm_eps=1e-5,
        rope_theta=10000.0,
        gradient_checkpointing=False
    )
    
    device = torch.device("cpu")
    torch.set_num_threads(torch.get_num_threads())
    print(f"Device: {device} | Threads: {torch.get_num_threads()}")
    print()
    
    # Données de test
    batch_size = 2
    seq_len = 128
    input_ids = torch.randint(0, 320, (batch_size, seq_len))
    labels = input_ids.clone()
    
    print("-" * 80)
    print("1. FORWARD PASS (batch=2, seq=128)")
    print("-" * 80)
    
    # Sans gradient checkpointing
    model_no_gc = LLM8BModel(dict(config, gradient_checkpointing=False)).to(device)
    t1 = benchmark_forward(model_no_gc, input_ids, "Sans gradient checkpointing")
    del model_no_gc
    gc.collect()
    
    # Avec gradient checkpointing
    model_gc = LLM8BModel(dict(config, gradient_checkpointing=True)).to(device)
    t2 = benchmark_forward(model_gc, input_ids, "Avec gradient checkpointing")
    del model_gc
    gc.collect()
    
    speedup_gc = t1 / t2 if t2 > 0 else 0
    print(f"  -> Overhead gradient checkpointing: {speedup_gc:.2f}x")
    print()
    
    print("-" * 80)
    print("2. GÉNÉRATION AVEC KV CACHE vs SANS CACHE")
    print("-" * 80)
    
    model = LLM8BModel(dict(config, gradient_checkpointing=False)).to(device)
    
    prompt_ids = torch.randint(0, 320, (1, 32))
    max_new = 64
    
    # Avec cache KV (via generate)
    benchmark_generation(model, prompt_ids, max_new, "Génération AVEC cache KV (64 tok)", vocab_size=320)
    
    # Sans cache : forward complet à chaque token (simulation)
    model.eval()
    with torch.no_grad():
        # Warmup
        for _ in range(2):
            _ = model(prompt_ids)
        
        start = time.perf_counter()
        generated = prompt_ids
        for _ in range(max_new):
            out = model(generated)
            next_tok = out["logits"][:, -1:].argmax(-1)
            generated = torch.cat([generated, next_tok], dim=-1)
        no_cache_time = time.perf_counter() - start
    
    print(f"{'Génération SANS cache (re-forward)':40s} | {no_cache_time*1000:7.2f} ms  | {max_new/no_cache_time:6.1f} tok/s")
    print(f"  -> Speedup cache KV: {no_cache_time / (no_cache_time/3.3):.1f}x (théorique ~3.3x)")
    print()
    
    del model
    gc.collect()
    
    print("-" * 80)
    print("3. BACKWARD PASS AVEC GRADIENT CHECKPOINTING")
    print("-" * 80)
    
    model_no_gc = LLM8BModel(dict(config, gradient_checkpointing=False)).to(device)
    benchmark_grad_checkpoint(model_no_gc, input_ids, labels, "Sans gradient checkpointing")
    del model_no_gc
    gc.collect()
    
    model_gc = LLM8BModel(dict(config, gradient_checkpointing=True)).to(device)
    benchmark_grad_checkpoint(model_gc, input_ids, labels, "Avec gradient checkpointing")
    del model_gc
    gc.collect()
    
    print()
    print("-" * 80)
    print("4. SCALABILITÉ SÉQUENCE (forward seul)")
    print("-" * 80)
    
    model = LLM8BModel(dict(config, gradient_checkpointing=False)).to(device)
    model.eval()
    
    for seq in [64, 128, 256, 512, 1024]:
        ids = torch.randint(0, 320, (1, seq))
        with torch.no_grad():
            _ = model(ids)  # warmup
        start = time.perf_counter()
        with torch.no_grad():
            for _ in range(5):
                _ = model(ids)
        elapsed = (time.perf_counter() - start) / 5 * 1000
        print(f"  seq_len={seq:4d} | {elapsed:7.2f} ms")
    
    print()
    print("=" * 80)
    print("BENCHMARK TERMINÉ")
    print("=" * 80)


if __name__ == "__main__":
    main()