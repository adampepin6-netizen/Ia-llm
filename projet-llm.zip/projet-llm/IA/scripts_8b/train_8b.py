"""
Script d'entraînement distribué DeepSpeed ZeRO-3 pour le modèle 8B.
Usage (sur cluster multi-GPU) :
  deepspeed IA/scripts_8b/train_8b.py --deepspeed IA/config_8b/ds_config_zero3.json
"""
import os
import sys
import json
import yaml
import torch
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.model_8b.model_8b import LLM8BModel
from src.tokenizer.bpe_tokenizer import BPETokenizer
from src.data.dataset import LanguageCodeDataset, build_dataloader, load_corpus


def load_yaml(path):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--local_rank", type=int, default=-1)
    parser.add_argument("--deepspeed", type=str, default=None)
    args = parser.parse_args()

    # DeepSpeed import
    import deepspeed

    config_path = os.path.join(os.path.dirname(__file__), "..", "config_8b", "config_8b.yaml")
    config = load_yaml(config_path)

    deepspeed.init_distributed()

    print(f"[Rank {os.environ.get('RANK', 0)}] Initialisation...")

    # Chargement / Tokeniseur
    tokenizer_path = os.path.join(os.path.dirname(__file__), "..", "data", "tokenizer.json")
    if os.path.exists(tokenizer_path):
        tokenizer = BPETokenizer.load(tokenizer_path)
    else:
        raise RuntimeError("Tokeniseur non trouvé. Exécutez d'abord scripts/train.py pour le générer.")

    # Data
    raw_dir = os.path.join(os.path.dirname(__file__), "..", "data", "raw")
    file_paths = load_corpus(raw_dir)
    dataset = LanguageCodeDataset(file_paths, tokenizer, max_length=2048)
    train_loader = build_dataloader(dataset, batch_size=config["training"]["micro_batch_size"])

    # Modèle
    model = LLM8BModel(dict(config["model"], gradient_checkpointing=config["training"].get(
        "gradient_checkpointing", False)))

    total_params = sum(p.numel() for p in model.parameters()) / 1e9
    print(f"Modèle 8B instancié : ~{total_params:.2f}B paramètres")

    # DeepSpeed Init
    ds_config_path = os.path.join(os.path.dirname(__file__), "..", "config_8b", "ds_config_zero3.json")
    with open(ds_config_path) as f:
        ds_config = json.load(f)

    model_engine, optimizer, _, _ = deepspeed.initialize(
        args=args,
        model=model,
        model_parameters=model.parameters(),
        config=ds_config
    )

    print("Début de l'entraînement 8B DeepSpeed ZeRO-3...")

    model_engine.train()
    step = 0
    for epoch in range(config["training"]["max_steps"]):
        for input_ids, labels in train_loader:
            input_ids = input_ids.to(model_engine.local_rank)
            labels = labels.to(model_engine.local_rank)

            outputs = model_engine(input_ids, labels=labels)
            loss = outputs["loss"]

            model_engine.backward(loss)
            model_engine.step()

            step += 1
            if step % config["training"]["logging_steps"] == 0 and model_engine.local_rank == 0:
                print(f"Step {step} | Loss: {loss.item():.4f}")

            if step % config["training"]["save_steps"] == 0:
                model_engine.save_checkpoint(config["training"]["output_dir"], tag=f"step_{step}")

            if step >= config["training"]["max_steps"]:
                break
        if step >= config["training"]["max_steps"]:
            break

    print("Entraînement 8B terminé.")


if __name__ == "__main__":
    main()
