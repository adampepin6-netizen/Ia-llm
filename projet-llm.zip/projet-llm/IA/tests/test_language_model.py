"""Régressions CPU des deux architectures et de la préparation du code."""
import sys
import tempfile
import unittest
from pathlib import Path

import torch
from torch.nn import functional as F

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.data.dataset import LanguageCodeDataset
from src.model.llm_model import LLMModel
from src.model_8b.model_8b import LLM8BModel
from src.tokenizer.bpe_tokenizer import BPETokenizer
from scripts_8b.inference_8b import generate


class LanguageModelTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        self.config = dict(hidden_size=32, num_attention_heads=4, num_key_value_heads=2,
                           num_hidden_layers=2, intermediate_size=64, vocab_size=320,
                           max_position_embeddings=24, hidden_dropout_prob=0.0)
        self.ids = torch.randint(0, 320, (2, 12))

    def test_code_roundtrip_and_training_targets(self):
        code = "def carré(x):\n    return x ** 2\n"
        tokenizer = BPETokenizer(320)
        tokenizer.train([code], verbose=False)
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "exemple.py"
            source.write_text(code, encoding="utf-8")
            path = Path(tmp) / "tokenizer.json"
            tokenizer.save(path)
            tokenizer = BPETokenizer.load(path)
            unseen = code + "# 🐍\n"
            self.assertEqual(tokenizer.decode(tokenizer.encode(unseen)), unseen)
            dataset = LanguageCodeDataset([source], tokenizer, max_length=8)
            targets = []
            for ids, labels in dataset:
                valid = labels != -100
                self.assertTrue(torch.equal(labels[valid], ids[valid]))
                targets.extend(labels[1:][valid[1:]].tolist())
            self.assertEqual(targets, tokenizer.encode(code)[1:] + [tokenizer.vocab["</s>"]])

    def test_causality_and_training(self):
        for cls in (LLMModel, LLM8BModel):
            with self.subTest(model=cls.__name__):
                model = cls(dict(self.config, gradient_checkpointing=True))
                labels = self.ids.clone()
                labels[:, -2:] = -100
                out = model(self.ids, labels)
                prefix = model(self.ids[:, :5])["logits"]
                torch.testing.assert_close(out["logits"][:, :5], prefix)
                expected = F.cross_entropy(out["logits"][:, :-1].reshape(-1, 320),
                                           labels[:, 1:].reshape(-1))
                torch.testing.assert_close(out["loss"], expected)
                out["loss"].backward()
                self.assertTrue(all(p.grad is not None and p.grad.isfinite().all()
                                    for p in model.parameters()))

    def test_masked_keys_do_not_affect_predictions(self):
        model = LLMModel(self.config).eval()
        mask = torch.ones_like(self.ids)
        mask[:, 2] = 0
        changed = self.ids.clone()
        changed[:, 2] = (changed[:, 2] + 1) % 320
        original = model(self.ids, attention_mask=mask)["logits"]
        modified = model(changed, attention_mask=mask)["logits"]
        torch.testing.assert_close(original[:, 3:], modified[:, 3:])

    def test_kv_cache(self):
        model = LLM8BModel(self.config).eval()
        full = model(self.ids)["logits"]
        cache = None
        for start, end in ((0, 5), (5, 6), (6, 12)):
            out = model(self.ids[:, start:end], past_key_values=cache, use_cache=True)
            torch.testing.assert_close(out["logits"], full[:, start:end])
            cache = out["past_key_values"]
            self.assertEqual(cache[0][0].shape, (2, 2, end, 8))
        generated = generate(model, self.ids, max_new_tokens=3, top_k=1)
        expected = self.ids
        for _ in range(3):
            nxt = model(expected)["logits"][:, -1].argmax(-1, keepdim=True)
            expected = torch.cat((expected, nxt), dim=1)
        self.assertTrue(torch.equal(expected, generated))


if __name__ == "__main__":
    unittest.main()
