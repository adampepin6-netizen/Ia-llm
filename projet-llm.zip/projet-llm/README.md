# Projet LLM - Langage et Codage

Un modèle de langage de grande taille (LLM) pour le langage naturel et le codage.

## Structure du projet

```
projet-llm/
├── IA/
│   ├── src/
│   │   ├── model/          # Architecture du modèle (Transformer)
│   │   ├── training/       # Script d'entraînement
│   │   ├── data/           # Chargement et prétraitement des données
│   │   ├── tokenizer/      # Tokeniseur
│   │   └── utils/          # Utilitaires
│   ├── config/             # Configurations
│   ├── data/               # Données (brutes et traitées)
│   ├── checkpoints/        # Sauvegardes des modèles
│   ├── logs/               # Logs d'entraînement
│   └── scripts/            # Scripts utilitaires
└── docs/                   # Documentation
```

## Démarrage rapide

```bash
cd projet-llm
pip install -r requirements.txt
python IA/scripts/preprocess.py
python IA/scripts/train.py
```
Les tests CPU utilisent des dimensions réduites pour vérifier la tokenisation du code, les cibles d’entraînement, la causalité et la génération avec cache KV.

```bash
python -m unittest discover -s IA/tests
```
